# Changelog

이 문서는 `web_perf_extension`의 주요 변경 이력을 기록합니다.

## v0.1.0 - 2026-04-14

초기 공개용 MVP 릴리스입니다.

### Added

- 현재 활성 탭의 로딩 성능 지표 측정 기능
- 새로고침 후 재측정 기능
- `TTFB`, `FCP`, `LCP`, `DOMContentLoaded`, `Load` 표시
- 리소스 수, 전송 크기 요약 표시
- 최근 측정 기록 저장, 다시 열기, 삭제 기능
- 확장프로그램 아이콘 배지에 현재 페이지 로드 속도 자동 표시
- `README.md` 기반 설치 및 실행 안내
- `npm.cmd run check:syntax` 문법 검증 스크립트

### Notes

- Chrome MV3 기반 로컬 압축해제 확장프로그램으로 동작합니다.
- `http`, `https` 페이지에서만 측정할 수 있습니다.

import {
  METRIC_ORDER,
  createInsightLines,
  formatBytes,
  formatMilliseconds,
  formatTimestamp,
  getMetricDefinition,
  getMetricTone,
} from '../lib/metric-utils.js';

export function cachePopupElements(documentRef) {
  return {
    targetTitle: documentRef.getElementById('targetTitle'),
    targetUrl: documentRef.getElementById('targetUrl'),
    measureCurrentBtn: documentRef.getElementById('measureCurrentBtn'),
    reloadMeasureBtn: documentRef.getElementById('reloadMeasureBtn'),
    saveRecordBtn: documentRef.getElementById('saveRecordBtn'),
    clearHistoryBtn: documentRef.getElementById('clearHistoryBtn'),
    statusBanner: documentRef.getElementById('statusBanner'),
    capturedAt: documentRef.getElementById('capturedAt'),
    metricsGrid: documentRef.getElementById('metricsGrid'),
    resourceCount: documentRef.getElementById('resourceCount'),
    transferSize: documentRef.getElementById('transferSize'),
    navigationType: documentRef.getElementById('navigationType'),
    insightList: documentRef.getElementById('insightList'),
    historyList: documentRef.getElementById('historyList'),
  };
}

export function renderTarget(elements, tab) {
  if (!tab) {
    elements.targetTitle.textContent = '활성 탭을 찾지 못했습니다.';
    elements.targetUrl.textContent = '-';
    return;
  }

  elements.targetTitle.textContent = tab.title || tab.url || '제목 없는 페이지';
  elements.targetUrl.textContent = tab.url || '-';
}

export function renderMeasurement(elements, measurement) {
  elements.metricsGrid.innerHTML = '';

  if (!measurement) {
    elements.capturedAt.textContent = '아직 측정 결과가 없습니다.';
    elements.resourceCount.textContent = '-';
    elements.transferSize.textContent = '-';
    elements.navigationType.textContent = '-';
    elements.insightList.innerHTML = '';
    const emptyItem = document.createElement('li');
    emptyItem.textContent = '측정을 실행하면 TTFB, FCP, LCP, DCL, Load 결과를 확인할 수 있습니다.';
    elements.insightList.appendChild(emptyItem);
    return;
  }

  elements.capturedAt.textContent = '측정 시각 ' + formatTimestamp(measurement.capturedAt);
  elements.resourceCount.textContent = String(measurement.resources.count || 0);
  elements.transferSize.textContent = formatBytes(measurement.resources.transferSize || 0);
  elements.navigationType.textContent = measurement.navigation.type || 'unknown';

  METRIC_ORDER.forEach((metricKey) => {
    const definition = getMetricDefinition(metricKey);
    const value = measurement.metrics[metricKey];
    const tone = getMetricTone(metricKey, value);

    const card = document.createElement('article');
    card.className = 'metric-card';
    card.dataset.tone = tone;

    const name = document.createElement('p');
    name.className = 'metric-name';
    name.textContent = definition.label;

    const metricValue = document.createElement('strong');
    metricValue.className = 'metric-value';
    metricValue.textContent = formatMilliseconds(value);

    const copy = document.createElement('p');
    copy.className = 'metric-copy';
    copy.textContent = definition.description;

    card.appendChild(name);
    card.appendChild(metricValue);
    card.appendChild(copy);
    elements.metricsGrid.appendChild(card);
  });

  elements.insightList.innerHTML = '';
  createInsightLines(measurement).forEach((line) => {
    const item = document.createElement('li');
    item.textContent = line;
    elements.insightList.appendChild(item);
  });
}

export function renderHistory(elements, historyItems) {
  elements.historyList.innerHTML = '';

  if (!historyItems.length) {
    const empty = document.createElement('div');
    empty.className = 'history-empty';
    empty.textContent = '저장된 측정 기록이 없습니다. 측정 후 기록 저장을 눌러주세요.';
    elements.historyList.appendChild(empty);
    return;
  }

  historyItems.forEach((item) => {
    const card = document.createElement('article');
    card.className = 'history-card';

    const head = document.createElement('div');
    head.className = 'history-card-head';

    const time = document.createElement('span');
    time.className = 'history-card-time';
    time.textContent = formatTimestamp(item.capturedAt);

    const host = document.createElement('span');
    host.className = 'history-card-host';
    host.textContent = safeHost(item.url);

    head.appendChild(time);
    head.appendChild(host);

    const title = document.createElement('div');
    title.className = 'history-card-title';
    title.textContent = item.title || item.url || '기록';

    const summary = document.createElement('div');
    summary.className = 'history-card-summary';
    summary.appendChild(createChip('TTFB ' + formatMilliseconds(item.metrics.ttfb)));
    summary.appendChild(createChip('FCP ' + formatMilliseconds(item.metrics.fcp)));
    summary.appendChild(createChip('LCP ' + formatMilliseconds(item.metrics.lcp)));

    const actions = document.createElement('div');
    actions.className = 'history-actions';

    const openButton = document.createElement('button');
    openButton.className = 'history-action';
    openButton.type = 'button';
    openButton.dataset.action = 'open';
    openButton.dataset.id = item.id;
    openButton.textContent = '열기';

    const removeButton = document.createElement('button');
    removeButton.className = 'history-action';
    removeButton.type = 'button';
    removeButton.dataset.action = 'remove';
    removeButton.dataset.id = item.id;
    removeButton.textContent = '삭제';

    actions.appendChild(openButton);
    actions.appendChild(removeButton);

    card.appendChild(head);
    card.appendChild(title);
    card.appendChild(summary);
    card.appendChild(actions);
    elements.historyList.appendChild(card);
  });
}

export function setStatus(elements, message, tone) {
  elements.statusBanner.textContent = message;
  elements.statusBanner.dataset.tone = tone || 'neutral';
}

export function setSaveEnabled(elements, enabled) {
  elements.saveRecordBtn.disabled = !enabled;
}

export function setActionBusy(button, isBusy, label) {
  button.disabled = isBusy;
  if (label) {
    button.textContent = label;
  }
}

function createChip(text) {
  const chip = document.createElement('span');
  chip.className = 'history-chip';
  chip.textContent = text;
  return chip;
}

function safeHost(url) {
  try {
    return new URL(url).hostname;
  } catch (error) {
    return url || '-';
  }
}

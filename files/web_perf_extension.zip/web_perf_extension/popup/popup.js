import { clearHistory, loadHistory, removeHistoryRecord, saveMeasurementToHistory } from '../lib/history-store.js';
import {
  cachePopupElements,
  renderHistory,
  renderMeasurement,
  renderTarget,
  setActionBusy,
  setSaveEnabled,
  setStatus,
} from './popup-view.js';

const state = {
  activeTab: null,
  currentMeasurement: null,
  history: [],
};

const elements = cachePopupElements(document);

document.addEventListener('DOMContentLoaded', init);

async function init() {
  bindEvents();
  state.activeTab = await readActiveTab();
  renderTarget(elements, state.activeTab);

  state.history = await loadHistory();
  renderHistory(elements, state.history);
  renderMeasurement(elements, null);
  setSaveEnabled(elements, false);

  if (!isSupportedTab(state.activeTab)) {
    setStatus(elements, 'http 또는 https 페이지에서만 측정할 수 있습니다.', 'bad');
    disableMeasureButtons();
    return;
  }

  setStatus(elements, '현재 탭을 자동 측정하는 중입니다.', 'neutral');
  await measureCurrentTab();
}

function bindEvents() {
  elements.measureCurrentBtn.addEventListener('click', measureCurrentTab);
  elements.reloadMeasureBtn.addEventListener('click', reloadAndMeasureCurrentTab);
  elements.saveRecordBtn.addEventListener('click', saveCurrentMeasurement);
  elements.clearHistoryBtn.addEventListener('click', clearSavedHistory);
  elements.historyList.addEventListener('click', handleHistoryAction);
}

async function readActiveTab() {
  const tabs = await chrome.tabs.query({
    active: true,
    lastFocusedWindow: true,
  });

  return tabs.length ? tabs[0] : null;
}

function isSupportedTab(tab) {
  return Boolean(tab && /^https?:/i.test(String(tab.url || '')));
}

async function measureCurrentTab() {
  await withBusy(elements.measureCurrentBtn, '측정 중...', async () => {
    const result = await chrome.runtime.sendMessage({
      type: 'measure-active-tab',
    });

    if (!result || !result.ok) {
      throw new Error(result && result.message ? result.message : '현재 탭 측정에 실패했습니다.');
    }

    applyMeasurement(result.payload, '현재 탭 측정이 완료되었습니다.', 'good');
  });
}

async function reloadAndMeasureCurrentTab() {
  await withBusy(elements.reloadMeasureBtn, '재측정 중...', async () => {
    const result = await chrome.runtime.sendMessage({
      type: 'reload-and-measure-active-tab',
    });

    if (!result || !result.ok) {
      throw new Error(result && result.message ? result.message : '새로고침 후 측정에 실패했습니다.');
    }

    applyMeasurement(result.payload, '새로고침 후 측정이 완료되었습니다.', 'good');
  });
}

async function saveCurrentMeasurement() {
  if (!state.currentMeasurement) {
    setStatus(elements, '저장할 측정 결과가 없습니다.', 'bad');
    return;
  }

  await withBusy(elements.saveRecordBtn, '저장 중...', async () => {
    state.history = await saveMeasurementToHistory(state.currentMeasurement);
    renderHistory(elements, state.history);
    setStatus(elements, '현재 측정 결과를 최근 기록에 저장했습니다.', 'good');
  }, '기록 저장');
}

async function clearSavedHistory() {
  if (!state.history.length) {
    setStatus(elements, '비울 기록이 없습니다.', 'neutral');
    return;
  }

  await withBusy(elements.clearHistoryBtn, '정리 중...', async () => {
    state.history = await clearHistory();
    renderHistory(elements, state.history);
    setStatus(elements, '최근 기록을 모두 삭제했습니다.', 'good');
  }, '기록 비우기');
}

async function handleHistoryAction(event) {
  const button = event.target.closest('button[data-action]');
  if (!button) {
    return;
  }

  const recordId = button.dataset.id || '';
  if (!recordId) {
    return;
  }

  if (button.dataset.action === 'open') {
    const target = state.history.find((item) => item.id === recordId);
    if (target && target.url) {
      await chrome.tabs.create({
        url: target.url,
      });
      setStatus(elements, '기록에 저장된 페이지를 새 탭에서 열었습니다.', 'good');
    }
    return;
  }

  if (button.dataset.action === 'remove') {
    state.history = await removeHistoryRecord(recordId);
    renderHistory(elements, state.history);
    setStatus(elements, '선택한 기록을 삭제했습니다.', 'good');
  }
}

function applyMeasurement(measurement, message, tone) {
  state.currentMeasurement = measurement;
  renderMeasurement(elements, measurement);
  setSaveEnabled(elements, true);
  setStatus(elements, message, tone);
}

async function withBusy(button, loadingLabel, task, restoreLabel) {
  const originalLabel = button.textContent;
  setActionBusy(button, true, loadingLabel);

  try {
    await task();
  } catch (error) {
    setStatus(elements, error instanceof Error ? error.message : '알 수 없는 오류가 발생했습니다.', 'bad');
  } finally {
    setActionBusy(button, false, restoreLabel || originalLabel);
    if (button === elements.saveRecordBtn) {
      setSaveEnabled(elements, Boolean(state.currentMeasurement));
    }
  }
}

function disableMeasureButtons() {
  elements.measureCurrentBtn.disabled = true;
  elements.reloadMeasureBtn.disabled = true;
  elements.saveRecordBtn.disabled = true;
}

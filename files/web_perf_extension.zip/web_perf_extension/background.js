const MEASURE_TIMEOUT_MS = 20000;
const POST_LOAD_DELAY_MS = 800;
const BADGE_LOADING_TEXT = '...';
const BADGE_ERROR_TEXT = 'ERR';
const DEFAULT_ACTION_TITLE = 'Web Perf Extension';
const BADGE_COLORS = {
  loading: '#4f67ff',
  good: '#1f9d55',
  warn: '#d89b00',
  bad: '#d14343',
  error: '#6b1f1f',
};
const METRIC_THRESHOLDS = {
  ttfb: {
    good: 800,
    needsImprovement: 1800,
  },
  fcp: {
    good: 1800,
    needsImprovement: 3000,
  },
  lcp: {
    good: 2500,
    needsImprovement: 4000,
  },
  domContentLoaded: {
    good: 2000,
    needsImprovement: 3500,
  },
  load: {
    good: 3000,
    needsImprovement: 5000,
  },
};

chrome.tabs.onActivated.addListener(({ tabId }) => {
  void syncBadgeForTab(tabId);
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'loading' || changeInfo.url) {
    if (isSupportedUrl(tab && tab.url)) {
      void setLoadingBadge(tabId, tab.url);
    } else {
      void clearBadge(tabId);
    }
    return;
  }

  if (changeInfo.status === 'complete') {
    void measureAndUpdateBadgeForTab(tabId, tab, POST_LOAD_DELAY_MS);
  }
});

chrome.runtime.onStartup.addListener(() => {
  void syncBadgeForActiveTab();
});

chrome.runtime.onInstalled.addListener(() => {
  void syncBadgeForActiveTab();
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || !message.type) {
    sendResponse({
      ok: false,
      message: '알 수 없는 요청입니다.',
    });
    return false;
  }

  handleMessage(message)
    .then((payload) => {
      sendResponse({
        ok: true,
        payload,
      });
    })
    .catch((error) => {
      sendResponse({
        ok: false,
        message: error instanceof Error ? error.message : '측정 중 오류가 발생했습니다.',
      });
    });

  return true;
});

async function handleMessage(message) {
  if (message.type === 'measure-active-tab') {
    const tab = await getActiveTab();
    assertSupportedTab(tab);
    const measurement = await measureTab(tab.id);
    await applyBadgeFromMeasurement(tab.id, tab.url, measurement);
    return measurement;
  }

  if (message.type === 'reload-and-measure-active-tab') {
    const tab = await getActiveTab();
    assertSupportedTab(tab);
    await setLoadingBadge(tab.id, tab.url);
    await chrome.tabs.reload(tab.id, {
      bypassCache: true,
    });
    await waitForTabComplete(tab.id, MEASURE_TIMEOUT_MS);
    await delay(POST_LOAD_DELAY_MS);
    const measurement = await measureTab(tab.id);
    await applyBadgeFromMeasurement(tab.id, tab.url, measurement);
    return measurement;
  }

  throw new Error('지원하지 않는 작업입니다.');
}

async function getActiveTab() {
  const tabs = await chrome.tabs.query({
    active: true,
    lastFocusedWindow: true,
  });

  if (!tabs.length) {
    throw new Error('활성 탭을 찾지 못했습니다.');
  }

  return tabs[0];
}

function assertSupportedTab(tab) {
  if (!tab || typeof tab.id !== 'number') {
    throw new Error('탭 정보를 읽지 못했습니다.');
  }

  if (!isSupportedUrl(tab.url)) {
    throw new Error('http 또는 https 페이지에서만 측정할 수 있습니다.');
  }
}

function isSupportedUrl(url) {
  return /^https?:/i.test(String(url || ''));
}

function waitForTabComplete(tabId, timeoutMs) {
  return new Promise((resolve, reject) => {
    let settled = false;
    let timerId = null;

    function cleanup() {
      chrome.tabs.onUpdated.removeListener(onUpdated);
      if (timerId) {
        clearTimeout(timerId);
      }
    }

    function resolveOnce() {
      if (settled) {
        return;
      }
      settled = true;
      cleanup();
      resolve();
    }

    function rejectOnce(error) {
      if (settled) {
        return;
      }
      settled = true;
      cleanup();
      reject(error);
    }

    function onUpdated(updatedTabId, changeInfo) {
      if (updatedTabId !== tabId || changeInfo.status !== 'complete') {
        return;
      }

      resolveOnce();
    }

    chrome.tabs.onUpdated.addListener(onUpdated);

    timerId = setTimeout(() => {
      rejectOnce(new Error('페이지 로드 완료를 기다리다 시간 초과되었습니다.'));
    }, timeoutMs);
  });
}

async function measureTab(tabId) {
  let results;

  try {
    results = await chrome.scripting.executeScript({
      target: {
        tabId,
      },
      func: collectPerformanceSnapshot,
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : '페이지 성능 스크립트를 실행하지 못했습니다.';
    throw new Error(message);
  }

  const measurement = Array.isArray(results) && results.length ? results[0].result : null;
  if (!measurement) {
    throw new Error('페이지 성능 정보를 읽지 못했습니다.');
  }

  if (measurement.error) {
    throw new Error(measurement.error);
  }

  return measurement;
}

async function syncBadgeForActiveTab() {
  try {
    const tab = await getActiveTab();
    await syncBadgeForTab(tab.id, tab);
  } catch (error) {
    return;
  }
}

async function syncBadgeForTab(tabId, existingTab) {
  const tab = existingTab || (await chrome.tabs.get(tabId));
  if (!tab || typeof tab.id !== 'number') {
    return;
  }

  if (!isSupportedUrl(tab.url)) {
    await clearBadge(tab.id);
    return;
  }

  if (tab.status === 'loading') {
    await setLoadingBadge(tab.id, tab.url);
    return;
  }

  await measureAndUpdateBadgeForTab(tab.id, tab, POST_LOAD_DELAY_MS);
}

async function measureAndUpdateBadgeForTab(tabId, existingTab, delayMs = 0) {
  const tab = existingTab || (await chrome.tabs.get(tabId));
  if (!tab || typeof tab.id !== 'number') {
    return;
  }

  if (!isSupportedUrl(tab.url)) {
    await clearBadge(tab.id);
    return;
  }

  if (delayMs > 0) {
    await delay(delayMs);
  }

  try {
    const measurement = await measureTab(tab.id);
    await applyBadgeFromMeasurement(tab.id, tab.url, measurement);
  } catch (error) {
    await setErrorBadge(tab.id, tab.url, error);
  }
}

async function applyBadgeFromMeasurement(tabId, url, measurement) {
  const badgeMetric = getBadgeMetric(measurement);
  if (!badgeMetric) {
    await chrome.action.setBadgeText({
      tabId,
      text: '',
    });
    await chrome.action.setTitle({
      tabId,
      title: createActionTitle(url, '표시할 로드 속도 지표가 없습니다.'),
    });
    return;
  }

  await chrome.action.setBadgeBackgroundColor({
    tabId,
    color: getBadgeColor(badgeMetric.key, badgeMetric.value),
  });
  await chrome.action.setBadgeText({
    tabId,
    text: formatBadgeText(badgeMetric.value),
  });
  await chrome.action.setTitle({
    tabId,
    title: createActionTitle(url, `${badgeMetric.label} ${formatBadgeSeconds(badgeMetric.value)}`),
  });
}

function getBadgeMetric(measurement) {
  if (!measurement || !measurement.metrics) {
    return null;
  }

  const candidates = [
    ['load', 'Load'],
    ['lcp', 'LCP'],
    ['domContentLoaded', 'DCL'],
    ['fcp', 'FCP'],
    ['ttfb', 'TTFB'],
  ];

  for (const [key, label] of candidates) {
    const value = measurement.metrics[key];
    if (typeof value === 'number' && Number.isFinite(value) && value > 0) {
      return {
        key,
        label,
        value,
      };
    }
  }

  return null;
}

function formatBadgeText(milliseconds) {
  if (typeof milliseconds !== 'number' || !Number.isFinite(milliseconds) || milliseconds <= 0) {
    return '';
  }

  const seconds = milliseconds / 1000;
  if (seconds < 10) {
    return seconds.toFixed(2);
  }

  if (seconds < 100) {
    return seconds.toFixed(1);
  }

  return '99+';
}

function formatBadgeSeconds(milliseconds) {
  return (milliseconds / 1000).toFixed(2) + 's';
}

function getBadgeColor(metricKey, value) {
  const thresholds = METRIC_THRESHOLDS[metricKey];
  if (!thresholds || typeof value !== 'number') {
    return BADGE_COLORS.warn;
  }

  if (value <= thresholds.good) {
    return BADGE_COLORS.good;
  }

  if (value <= thresholds.needsImprovement) {
    return BADGE_COLORS.warn;
  }

  return BADGE_COLORS.bad;
}

async function setLoadingBadge(tabId, url) {
  await chrome.action.setBadgeBackgroundColor({
    tabId,
    color: BADGE_COLORS.loading,
  });
  await chrome.action.setBadgeText({
    tabId,
    text: BADGE_LOADING_TEXT,
  });
  await chrome.action.setTitle({
    tabId,
    title: createActionTitle(url, '페이지 로드 속도를 측정하는 중입니다.'),
  });
}

async function setErrorBadge(tabId, url, error) {
  const detail = error instanceof Error ? error.message : '로드 속도 측정에 실패했습니다.';
  await chrome.action.setBadgeBackgroundColor({
    tabId,
    color: BADGE_COLORS.error,
  });
  await chrome.action.setBadgeText({
    tabId,
    text: BADGE_ERROR_TEXT,
  });
  await chrome.action.setTitle({
    tabId,
    title: createActionTitle(url, detail),
  });
}

async function clearBadge(tabId) {
  await chrome.action.setBadgeText({
    tabId,
    text: '',
  });
  await chrome.action.setTitle({
    tabId,
    title: DEFAULT_ACTION_TITLE,
  });
}

function createActionTitle(url, detail) {
  const cleanUrl = typeof url === 'string' && url ? url : '현재 탭';
  return `${DEFAULT_ACTION_TITLE}\n${detail}\n${cleanUrl}`;
}

function collectPerformanceSnapshot() {
  function roundMetric(value) {
    if (typeof value !== 'number' || !Number.isFinite(value) || value <= 0) {
      return null;
    }

    return Math.round(value * 10) / 10;
  }

  try {
    const navigationEntry = performance.getEntriesByType('navigation')[0] || null;
    const paintEntries = performance.getEntriesByType('paint');
    const fcpEntry = paintEntries.find((entry) => entry.name === 'first-contentful-paint') || null;
    const lcpEntries = performance.getEntriesByType('largest-contentful-paint');
    const lcpEntry = lcpEntries.length ? lcpEntries[lcpEntries.length - 1] : null;
    const resourceEntries = performance.getEntriesByType('resource');

    const resourceSummary = resourceEntries.reduce(
      (summary, entry) => {
        summary.count += 1;
        summary.transferSize += Number(entry.transferSize) || 0;
        summary.decodedBodySize += Number(entry.decodedBodySize) || 0;
        return summary;
      },
      {
        count: 0,
        transferSize: 0,
        decodedBodySize: 0,
      }
    );

    return {
      title: document.title || location.hostname,
      url: location.href,
      capturedAt: new Date().toISOString(),
      readyState: document.readyState,
      metrics: {
        ttfb: roundMetric(navigationEntry ? navigationEntry.responseStart : null),
        domContentLoaded: roundMetric(navigationEntry ? navigationEntry.domContentLoadedEventEnd : null),
        load: roundMetric(navigationEntry ? navigationEntry.loadEventEnd : null),
        fcp: roundMetric(fcpEntry ? fcpEntry.startTime : null),
        lcp: roundMetric(lcpEntry ? lcpEntry.startTime : null),
      },
      resources: resourceSummary,
      navigation: {
        type: navigationEntry && navigationEntry.type ? navigationEntry.type : 'unknown',
        redirectCount: navigationEntry ? navigationEntry.redirectCount : 0,
      },
    };
  } catch (error) {
    return {
      error: error instanceof Error ? error.message : '페이지 성능 정보를 읽지 못했습니다.',
    };
  }
}

function delay(timeoutMs) {
  return new Promise((resolve) => {
    setTimeout(resolve, timeoutMs);
  });
}

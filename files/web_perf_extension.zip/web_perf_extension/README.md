# Web Perf Extension

웹사이트의 로딩 속도를 빠르게 측정하는 Chrome 확장프로그램 프로젝트입니다.

## 현재 범위

- 현재 탭 성능 측정
- 새로고침 후 재측정
- 확장프로그램 아이콘 배지에 현재 페이지 로드 속도 자동 표시
- 최근 측정 기록 저장
- 저장 기록 다시 열기 및 삭제

## 측정 항목

- `TTFB`
- `FCP`
- `LCP`
- `DOMContentLoaded`
- `Load`
- 리소스 수
- 전송 크기

## 아이콘 배지 표시

- 기본적으로 `Load` 시간을 아이콘 배지에 초 단위로 표시합니다.
- `Load` 값이 없으면 `LCP`, `DOMContentLoaded`, `FCP`, `TTFB` 순서로 대체 표시합니다.
- 색상 기준:
  - 초록: 빠름
  - 노랑: 보통
  - 빨강: 느림
- 페이지 로딩 중에는 `...`가 보일 수 있습니다.

## 구조

- `manifest.json`: Chrome MV3 설정
- `background.js`: 활성 탭 측정과 새로고침 후 재측정 처리
- `popup/`: popup UI와 렌더링 로직
- `lib/metric-utils.js`: 지표 포맷과 threshold 분류
- `lib/history-store.js`: `chrome.storage.local` 기반 기록 저장
- `docs/mvp_spec.md`: MVP 범위 정의

## 실행 방법

1. Chrome에서 `chrome://extensions`를 엽니다.
2. 우측 상단 `개발자 모드`를 켭니다.
3. `압축해제된 확장 프로그램을 로드합니다`를 클릭합니다.
4. `D:\Workspace\web_perf_extension` 폴더를 선택합니다.
5. 확장프로그램 아이콘을 클릭해 popup을 엽니다.
6. 일반 `http` 또는 `https` 페이지로 이동하면 아이콘 배지에 로드 속도가 자동 표시됩니다.

## 검증

```powershell
cd D:\Workspace\web_perf_extension
npm.cmd run check:syntax
```

## 제한사항

- `http`, `https` 페이지에서만 측정할 수 있습니다.
- `LCP`는 페이지 상태에 따라 비어 있을 수 있습니다.
- 정밀 진단은 Lighthouse, DevTools와 함께 보는 것이 좋습니다.

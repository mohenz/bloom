# Web Perf Extension MVP

## 목적

- 현재 열려 있는 웹 페이지의 로딩 속도를 빠르게 측정한다.
- 브라우저 내에서 반복 측정 결과를 저장하고 비교한다.

## MVP 범위

1. 현재 탭 측정
- TTFB
- FCP
- LCP
- DOMContentLoaded
- Load
- 리소스 수
- 전송 크기

2. 새로고침 후 재측정
- 캐시 우회 새로고침 후 동일 지표 재측정

3. 최근 기록 저장
- 최대 20건 저장
- 기록별 URL, 제목, 측정 시각 저장
- 기록 열기
- 기록 삭제
- 전체 기록 비우기

## 제외 범위

- 서버 연동
- CSV 내보내기
- Lighthouse 수준의 심층 진단
- 자동 다중 URL 크롤링
- DevTools 전용 패널

## 기술 구조

- `background.js`
  - 활성 탭 조회
  - 새로고침 후 완료 대기
  - `chrome.scripting.executeScript` 로 성능 지표 수집

- `popup/`
  - popup UI
  - 결과 렌더링
  - 최근 기록 액션

- `lib/metric-utils.js`
  - 지표 포맷
  - threshold 기반 상태 분류

- `lib/history-store.js`
  - `chrome.storage.local` 기반 기록 저장

## 주의사항

- `chrome://`, `edge://`, `chrome-extension://` 같은 특수 페이지는 측정 불가
- LCP는 페이지 상태와 측정 타이밍에 따라 `n/a`가 될 수 있음
- 이 확장프로그램은 브라우저 내 빠른 참고용이며, 최종 정밀 분석은 Lighthouse나 DevTools와 함께 보는 것이 좋음

# GitHub Release Draft - v0.1.0

아래 내용을 GitHub Release 본문에 그대로 붙여넣어 사용할 수 있습니다.

## Suggested Title

`Web Perf Extension v0.1.0`

## Suggested Tag

`v0.1.0`

## Release Notes

Initial MVP release of `Web Perf Extension`.

### Highlights

- Measure loading speed metrics for the current active tab
- Re-measure after hard reload
- Show page speed directly on the extension action badge
- Save and manage recent measurement history locally

### Included in this release

- `TTFB`, `FCP`, `LCP`, `DOMContentLoaded`, `Load` metric collection
- Resource count and transfer size summary
- Automatic badge update when tabs change or page loads complete
- Popup UI for measure, reload-measure, save, reopen, and delete actions
- Local history storage using `chrome.storage.local`

### How to use

1. Open `chrome://extensions`
2. Enable `Developer mode`
3. Click `Load unpacked`
4. Select the project folder
5. Open any `http` or `https` page
6. Check the action badge and popup for performance metrics

### Verification

- Syntax verification passed with `npm.cmd run check:syntax`

### Known limitations

- Only `http` and `https` pages are supported
- Some metrics such as `LCP` may be unavailable depending on page state
- This release is intended as a local unpacked Chrome extension MVP

### Next candidates

- CSV export
- Measurement comparison view
- DevTools panel mode

import { readFileSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const filesToCheck = [
  'background.js',
  'lib/metric-utils.js',
  'lib/history-store.js',
  'popup/popup.js',
  'popup/popup-view.js',
];

const manifestRaw = readFileSync(new URL('../manifest.json', import.meta.url), 'utf8');
JSON.parse(manifestRaw);

for (const relativePath of filesToCheck) {
  const targetPath = fileURLToPath(new URL('../' + relativePath, import.meta.url));
  const result = spawnSync(process.execPath, ['--check', targetPath], {
    stdio: 'inherit',
  });

  if (result.status !== 0) {
    process.exit(result.status || 1);
  }
}

console.log('syntax ok');
